def potencia(base,exponente):
	print("Resultado de la potencia: ",base**exponente)	
	
def redondear(numero):
	print("El resultado del redondeo: ",round(numero))
