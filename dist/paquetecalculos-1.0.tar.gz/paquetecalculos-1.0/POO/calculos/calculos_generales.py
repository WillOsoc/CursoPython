def sumar(n1,n2):
	print("Resultado de la suma: ",n1+n2)

def restar(n1,n2):
	print("Resultado de la resta: ",n1-n2)
	
def multiplicar(n1,n2):
	print("Resultado de la multiplicación: ",n1*n2)
	
def dividir(n1,n2):
	print("Resultado de la división: ",n1/n2)

