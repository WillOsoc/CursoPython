from setuptools import setup

setup(
	name="paquetecalculos",
	version="1.0",
	description="Cálculos extras",
	author="Will",
	author_email="wilfer.osorio@gmail.com",
	packages=["POO.calculos","POO.calculos.extras"]

	)